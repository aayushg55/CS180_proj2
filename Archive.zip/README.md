# CS180_proj2
Fun with Filters_and_Frequencies

The code for the Hybrid section (Part 2.2) is in hybrid.py. The rest is in main.ipynb.